﻿@echo off
chcp 65001 >nul 2>&1
rem 重新编译原生窗口宿主 TmsDiaryHost.exe
rem 需要 .NET Framework 4.x 自带的 csc.exe（Windows 自带）
set CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe
cd /d "%~dp0"
if not exist sdk\Microsoft.Web.WebView2.Core.dll (
  echo 缺少 sdk 目录下的 WebView2 DLL
  pause & exit /b 1
)
"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ ^
  /out:..\_internal\TmsDiaryHost.exe ^
  /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll ^
  /r:System.Net.dll /r:System.Core.dll ^
  /r:sdk\Microsoft.Web.WebView2.Core.dll ^
  /r:sdk\Microsoft.Web.WebView2.WinForms.dll ^
  Host.cs
if errorlevel 1 (
  echo 编译失败
) else (
  echo 编译成功，已输出到 ..\_internal\TmsDiaryHost.exe
)
pause
