// 日记管理系统 · 原生窗口宿主
// WinForms + WebView2，得到一个真正的桌面窗口（无地址栏、无标签页、无浏览器外壳）。
// 由 日记管理系统.exe 启动，参数：<url> <logPath> <userDataDir>
using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

static class HostLog
{
    public static string Path;
    public static void Write(string msg)
    {
        try
        {
            if (string.IsNullOrEmpty(Path)) return;
            File.AppendAllText(Path,
                "[" + DateTime.Now.ToString("HH:mm:ss") + "] [HOST] " + msg + "\r\n",
                Encoding.UTF8);
        }
        catch { }
    }
}

class MainForm : Form
{
    private readonly string _url;
    private readonly string _profile;
    private WebView2 _web;
    private Label _tip;
    private bool _closing;

    public MainForm(string url, string profile)
    {
        _url = url;
        _profile = profile;

        Text = "日记管理系统";
        Width = 1280;
        Height = 900;
        MinimumSize = new Size(760, 560);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(250, 248, 245);
        Font = new Font("Microsoft YaHei", 10f);

        _tip = new Label();
        _tip.Text = "正在打开日记…";
        _tip.Dock = DockStyle.Fill;
        _tip.TextAlign = ContentAlignment.MiddleCenter;
        _tip.ForeColor = Color.FromArgb(150, 140, 128);
        _tip.Font = new Font("Microsoft YaHei", 12f);
        Controls.Add(_tip);

        Load += OnLoaded;
        FormClosing += OnClosing;
    }

    // 用一套配置尝试创建 WebView2；失败返回 false 以便换配置重试
    private async Task<bool> TryOpen(string profile, string extraArgs)
    {
        HostLog.Write("尝试初始化：profile=" + (profile ?? "(默认)") +
                      " args=" + (extraArgs ?? "(无)"));
        WebView2 wv = new WebView2();
        wv.Dock = DockStyle.Fill;
        wv.Visible = false;
        wv.DefaultBackgroundColor = Color.FromArgb(250, 248, 245);
        Controls.Add(wv);
        wv.BringToFront();
        try
        {
            CoreWebView2Environment env;
            if (!string.IsNullOrEmpty(extraArgs))
            {
                var opt = new CoreWebView2EnvironmentOptions(extraArgs);
                env = await CoreWebView2Environment.CreateAsync(null, profile, opt);
            }
            else
            {
                env = await CoreWebView2Environment.CreateAsync(null, profile, null);
            }

            await wv.EnsureCoreWebView2Async(env);
            HostLog.Write("WebView2 初始化成功，内核版本 " +
                          wv.CoreWebView2.Environment.BrowserVersionString);

            var s = wv.CoreWebView2.Settings;
            try
            {
                s.IsStatusBarEnabled = false;
                s.AreDevToolsEnabled = true;
                s.IsZoomControlEnabled = true;
                s.IsPasswordAutosaveEnabled = false;
                s.IsGeneralAutofillEnabled = false;
            }
            catch { }

            wv.CoreWebView2.NavigationCompleted += OnNavCompleted;
            wv.CoreWebView2.ProcessFailed += delegate(object o, CoreWebView2ProcessFailedEventArgs pe)
            {
                HostLog.Write("WebView2 进程异常：" + pe.ProcessFailedKind);
            };

            _web = wv;
            HostLog.Write("导航到 " + _url);
            wv.CoreWebView2.Navigate(_url);
            return true;
        }
        catch (Exception ex)
        {
            HostLog.Write("本次初始化失败：" + ex.GetType().Name + " " + ex.Message);
            try { Controls.Remove(wv); wv.Dispose(); } catch { }
            return false;
        }
    }

    private async void OnLoaded(object sender, EventArgs e)
    {
        HostLog.Write("窗体已创建，开始初始化 WebView2");

        string profile = _profile;
        if (!string.IsNullOrEmpty(profile))
        {
            try { Directory.CreateDirectory(profile); }
            catch (Exception ex) { HostLog.Write("创建配置目录失败：" + ex.Message); profile = null; }
        }

        bool ok = false;
        // ① 首选：自己的配置目录
        if (!string.IsNullOrEmpty(profile)) ok = await TryOpen(profile, null);
        // ② 去掉 GPU 加速（兼容显卡驱动异常/受限环境）
        if (!ok) ok = await TryOpen(profile, "--disable-gpu");
        // ③ 用系统默认配置目录
        if (!ok) ok = await TryOpen(null, null);
        // ④ 默认配置 + 关 GPU
        if (!ok) ok = await TryOpen(null, "--disable-gpu");

        if (!ok)
        {
            HostLog.Write("所有初始化方式都失败");
            _tip.Text = "内置浏览器内核启动失败。\r\n\r\n" +
                        "请确认已安装 Microsoft Edge WebView2 运行时。";
            MessageBox.Show(
                "内置浏览器内核启动失败。\r\n\r\n" +
                "请安装「Microsoft Edge WebView2 Runtime」后重试。\r\n" +
                "（多数 Windows 10/11 已自带）\r\n\r\n" +
                "详细原因见日志：\r\n" + HostLog.Path,
                "日记管理系统", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Close();
        }
    }

    private void OnNavCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
    {
        HostLog.Write("页面加载完成，成功=" + e.IsSuccess +
            (e.IsSuccess ? "" : "，错误=" + e.WebErrorStatus));
        if (e.IsSuccess)
        {
            if (_web != null) _web.Visible = true;
            _tip.Visible = false;
        }
        else
        {
            _tip.Visible = true;
            _tip.Text = "页面加载失败：" + e.WebErrorStatus;
        }
    }

    private void OnClosing(object sender, FormClosingEventArgs e)
    {
        if (_closing) return;
        _closing = true;
        HostLog.Write("窗口关闭，通知后台退出");
        try
        {
            var req = (HttpWebRequest)WebRequest.Create(BaseUrl() + "api/shutdown");
            req.Method = "POST";
            req.Timeout = 2000;
            req.ContentLength = 0;
            req.BeginGetResponse(delegate(IAsyncResult ar)
            {
                try { req.EndGetResponse(ar).Close(); } catch { }
            }, null);
            Thread.Sleep(120);
        }
        catch { }
    }

    private string BaseUrl()
    {
        try
        {
            var u = new Uri(_url);
            return u.Scheme + "://" + u.Authority + "/";
        }
        catch { return "http://127.0.0.1:47321/"; }
    }
}

static class Program
{
    // WebView2 必须在 STA 线程上创建（WinForms 也要求 STA）
    [STAThread]
    static void Main(string[] args)
    {
        string url = args.Length > 0 ? args[0] : "http://127.0.0.1:47321/";
        HostLog.Path = args.Length > 1 ? args[1] : null;
        string profile = args.Length > 2 ? args[2] : null;

        HostLog.Write("宿主启动 url=" + url + " profile=" + profile);

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.ThreadException += delegate(object s, ThreadExceptionEventArgs te)
        {
            HostLog.Write("UI 线程异常：" + te.Exception);
        };
        AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs ue)
        {
            HostLog.Write("未捕获异常：" + ue.ExceptionObject);
        };

        try
        {
            Application.Run(new MainForm(url, profile));
        }
        catch (Exception ex)
        {
            HostLog.Write("启动失败：" + ex);
            try
            {
                MessageBox.Show("日记窗口启动失败：\r\n" + ex.Message,
                    "日记管理系统", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch { }
        }
        HostLog.Write("宿主退出");
    }
}
