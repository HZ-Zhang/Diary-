#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
日记管理系统 · 桌面版（exe 宿主）
=================================

作用：
  1. 在 127.0.0.1 起一个极小的本地服务，提供页面和读写接口
  2. 数据以**真实文件**形式存在  <exe 所在目录>\\data\\  下
  3. 用 Edge 的「应用模式」打开一个独立窗口（无地址栏，像原生软件）

数据文件结构：
  data\\
    meta.json          账号表等元数据
    entries.json       所有日记（加密过的密文）
    trash.json         回收站
    photos\\
      <图片id>.json    每张图片单独一个文件（加密的）
    app.log            运行日志

为什么数据放在这里：
  不依赖浏览器把数据存到哪。程序自己写文件，所以「拷走整个文件夹」
  就等于搬家，用任何备份工具都能备份。

命令行参数（一般用不到）：
  --serve-only    只起服务，不开窗口（用于自检/排错）
  --port N        指定端口
  --no-browser    起服务但不开窗口
"""

import os
import sys
import json
import time
import socket
import threading
import subprocess
import tempfile
import traceback
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote

APP_ID = 'diary'
APP_VER = '1.1'
HTML_NAME = '日记管理系统.html'
HOST_NAME = 'TmsDiaryHost.exe'      # 原生 WebView2 窗口宿主
PRIMARY_PORT = 47321      # 固定端口：既有稳定地址，也能防止多开

# ---------------------------------------------------------------- 路径

def base_dir():
    """exe 所在目录（打包后）或脚本所在目录（开发时）"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def res_dir():
    """打包后资源被解到 _MEIPASS"""
    if getattr(sys, 'frozen', False):
        return getattr(sys, '_MEIPASS', base_dir())
    return base_dir()


BASE = base_dir()
DATA = os.path.join(BASE, 'data')
PHOTOS = os.path.join(DATA, 'photos')
LOG_PATH = os.path.join(DATA, 'app.log')

LOCK = threading.Lock()
SHUTDOWN_FLAG = threading.Event()
STATE = {'last_ping': 0.0, 'page_loaded': False}


def say(msg):
    """无控制台窗口（--noconsole）时 sys.stdout 是 None，print 会抛异常"""
    try:
        if sys.stdout is not None:
            print(msg)
    except Exception:
        pass


def log(msg):
    line = '[%s] %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg)
    try:
        os.makedirs(DATA, exist_ok=True)
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass
    say(line)


def ensure_dirs():
    os.makedirs(DATA, exist_ok=True)
    os.makedirs(PHOTOS, exist_ok=True)


# ---------------------------------------------------------------- 文件读写

def _read_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except Exception as e:
        log('读取失败 %s : %s' % (path, e))
        return default


def _write_json(path, obj):
    """原子写：先写 .tmp 再 replace，避免写一半断电导致文件损坏"""
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, separators=(',', ':'))
    os.replace(tmp, path)


def _safe_id(s):
    """id 只允许字母数字下划线短横线，防止目录穿越"""
    s = str(s)
    return ''.join(c for c in s if c.isalnum() or c in '-_')[:80] or 'x'


STORE_FILE = {
    'meta': os.path.join(DATA, 'meta.json'),
    'entries': os.path.join(DATA, 'entries.json'),
    'trash': os.path.join(DATA, 'trash.json'),
}


def load_store(name):
    return _read_json(STORE_FILE[name], {})


def save_store(name, obj):
    _write_json(STORE_FILE[name], obj)


def photo_path(pid):
    return os.path.join(PHOTOS, _safe_id(pid) + '.json')


def usage_bytes():
    total = 0
    for root, _dirs, files in os.walk(DATA):
        # 跳过浏览器临时目录和日志
        if os.path.basename(root).startswith('_'):
            continue
        for fn in files:
            if fn == 'app.log':
                continue
            try:
                total += os.path.getsize(os.path.join(root, fn))
            except OSError:
                pass
    return total


# ---------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    server_version = 'DiaryLocal/1.0'
    protocol_version = 'HTTP/1.1'

    # ---- 工具 ----
    def _send(self, code, body, ctype='application/json; charset=utf-8'):
        if isinstance(body, str):
            body = body.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False))

    def _err(self, code, msg):
        self._json({'ok': False, 'error': msg}, code)

    def _body(self):
        try:
            n = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            n = 0
        if n <= 0:
            return {}
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode('utf-8'))
        except Exception:
            return None

    def log_message(self, fmt, *args):
        """把请求写进日志（跳过心跳，避免日志膨胀）"""
        try:
            msg = fmt % args if args else str(fmt)
        except Exception:
            msg = str(fmt)
        if 'ping' in msg:
            return
        log('HTTP ' + msg)

    # ---- 路由 ----
    def do_GET(self):
        try:
            self._route('GET')
        except Exception:
            log('GET 异常：\n' + traceback.format_exc())
            self._err(500, 'internal error')

    def do_PUT(self):
        try:
            self._route('PUT')
        except Exception:
            log('PUT 异常：\n' + traceback.format_exc())
            self._err(500, 'internal error')

    def do_POST(self):
        try:
            self._route('POST')
        except Exception:
            log('POST 异常：\n' + traceback.format_exc())
            self._err(500, 'internal error')

    def do_DELETE(self):
        try:
            self._route('DELETE')
        except Exception:
            log('DELETE 异常：\n' + traceback.format_exc())
            self._err(500, 'internal error')

    def _route(self, method):
        path = urlparse(self.path).path
        parts = [unquote(p) for p in path.split('/') if p]

        # 首页
        if method == 'GET' and (not parts or parts == ['index.html']):
            return self._index()

        if not parts or parts[0] != 'api':
            return self._err(404, 'not found')

        tail = parts[1:]

        # /api/health
        if tail == ['health'] and method == 'GET':
            return self._json({'ok': True, 'app': APP_ID, 'ver': APP_VER,
                               'dir': DATA})

        # /api/storage
        if tail == ['storage'] and method == 'GET':
            with LOCK:
                return self._json({'usage': usage_bytes(), 'dir': DATA})

        # /api/ping —— 页面心跳，用于判断窗口是否还开着
        if tail == ['ping']:
            STATE['last_ping'] = time.time()
            STATE['page_loaded'] = True
            return self._json({'ok': True})

        # /api/shutdown
        if tail == ['shutdown'] and method == 'POST':
            self._json({'ok': True})
            SHUTDOWN_FLAG.set()
            return

        # /api/clear/<store>
        if len(tail) == 2 and tail[0] == 'clear' and method == 'POST':
            store = tail[1]
            with LOCK:
                if store == 'photos':
                    for fn in os.listdir(PHOTOS):
                        try:
                            os.remove(os.path.join(PHOTOS, fn))
                        except OSError:
                            pass
                    return self._json({'ok': True})
                if store in STORE_FILE:
                    save_store(store, {})
                    return self._json({'ok': True})
            return self._err(400, 'bad store')

        # /api/meta ...
        if tail and tail[0] == 'meta':
            return self._meta(method, tail)

        # /api/photos ...
        if tail and tail[0] == 'photos':
            return self._photos(method, tail)

        # /api/entries | /api/trash
        if tail and tail[0] in ('entries', 'trash'):
            return self._records(method, tail[0], tail)

        return self._err(404, 'not found')

    def _index(self):
        path = os.path.join(res_dir(), HTML_NAME)
        if not os.path.exists(path):
            path = os.path.join(BASE, HTML_NAME)
        if not os.path.exists(path):
            return self._err(500, '找不到 ' + HTML_NAME)
        with open(path, 'rb') as f:
            data = f.read()
        self._send(200, data, 'text/html; charset=utf-8')

    def _meta(self, method, tail):
        with LOCK:
            data = load_store('meta')
            if len(tail) >= 2 and tail[1] == 'all' and method == 'GET':
                return self._json({'entries': data})
            if len(tail) < 2:
                return self._err(400, 'need key')
            key = tail[1]
            if method == 'GET':
                return self._json({'value': data.get(key)})
            if method == 'PUT':
                body = self._body()
                if body is None:
                    return self._err(400, 'bad json')
                data[key] = body.get('value')
                save_store('meta', data)
                return self._json({'ok': True})
            if method == 'DELETE':
                data.pop(key, None)
                save_store('meta', data)
                return self._json({'ok': True})
        return self._err(405, 'method not allowed')

    def _photos(self, method, tail):
        if len(tail) >= 2 and tail[1] == 'all':
            if method != 'GET':
                return self._err(405, 'method not allowed')
            out = {}
            with LOCK:
                for fn in os.listdir(PHOTOS):
                    if not fn.endswith('.json'):
                        continue
                    rec = _read_json(os.path.join(PHOTOS, fn), None)
                    if isinstance(rec, dict) and rec.get('id'):
                        out[rec['id']] = rec
            return self._json({'entries': out})

        if len(tail) < 2:
            return self._err(400, 'need id')
        pid = _safe_id(tail[1])
        fp = photo_path(pid)

        if method == 'GET':
            rec = _read_json(fp, None)
            return self._json({'rec': rec})

        if method == 'PUT':
            body = self._body()
            if body is None or not isinstance(body.get('rec'), dict):
                return self._err(400, 'bad json')
            rec = body['rec']
            rec.setdefault('id', pid)
            with LOCK:
                _write_json(fp, rec)
            return self._json({'ok': True})

        if method == 'DELETE':
            with LOCK:
                try:
                    os.remove(fp)
                except FileNotFoundError:
                    pass
            return self._json({'ok': True})

        return self._err(405, 'method not allowed')

    def _records(self, method, store, tail):
        if len(tail) < 2:
            if method == 'GET':
                with LOCK:
                    return self._json({'entries': load_store(store)})
            if method == 'PUT':
                body = self._body()
                if body is None or not isinstance(body.get('rec'), dict):
                    return self._err(400, 'bad json')
                rid = body.get('id') or body['rec'].get('id')
                if not rid:
                    return self._err(400, 'need id')
                with LOCK:
                    data = load_store(store)
                    data[str(rid)] = body['rec']
                    save_store(store, data)
                return self._json({'ok': True})
            return self._err(405, 'method not allowed')

        rid = str(tail[1])
        if method == 'GET':
            with LOCK:
                return self._json({'rec': load_store(store).get(rid)})
        if method == 'DELETE':
            with LOCK:
                data = load_store(store)
                data.pop(rid, None)
                save_store(store, data)
            return self._json({'ok': True})
        return self._err(405, 'method not allowed')


# ---------------------------------------------------------------- 启动

def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def find_browser():
    cands = [
        os.path.join(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)'),
                     'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        os.path.join(os.environ.get('ProgramFiles', r'C:\Program Files'),
                     'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        os.path.join(os.environ.get('ProgramFiles', r'C:\Program Files'),
                     'Google', 'Chrome', 'Application', 'chrome.exe'),
        os.path.join(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)'),
                     'Google', 'Chrome', 'Application', 'chrome.exe'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''),
                     'Google', 'Chrome', 'Application', 'chrome.exe'),
    ]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None


def msgbox(text, title='日记管理系统'):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)
    except Exception:
        pass


def host_exe_path():
    for d in (res_dir(), BASE):
        p = os.path.join(d, HOST_NAME)
        if os.path.exists(p):
            return p
    return None


def open_browser(url, want_app=True, allow_host=True):
    """打开日记界面。

    首选：内置 WebView2 原生窗口（TmsDiaryHost.exe）——
          真正的桌面窗口，无地址栏、无标签页、不依赖 Edge 配置。
    兜底：Edge/Chrome 应用窗口，再兜底浏览器标签页。
    """
    # ① 原生窗口
    hp = host_exe_path() if allow_host else None
    if hp:
        profile = os.path.join(BASE, '.webview2')
        try:
            subprocess.Popen([hp, url, LOG_PATH, profile])
            log('已启动原生窗口：' + hp)
            return 'host'
        except Exception as e:
            log('原生窗口启动失败：%s' % e)

    # ② 浏览器应用窗口
    if want_app:
        b = find_browser()
        if b:
            try:
                subprocess.Popen([
                    b, '--app=' + url,
                    '--no-first-run', '--no-default-browser-check',
                    '--window-size=1280,900',
                ])
                log('已打开浏览器应用窗口：' + b)
                return 'app'
            except Exception as e:
                log('应用窗口启动失败：%s' % e)

    # ③ 普通标签页
    try:
        os.startfile(url)
        log('已用默认浏览器打开：' + url)
        return 'tab'
    except Exception as e1:
        log('os.startfile 失败：%s' % e1)

    try:
        import webbrowser
        ok = webbrowser.open(url)
        log('webbrowser.open -> %s' % ok)
        return 'tab' if ok else 'none'
    except Exception as e2:
        log('webbrowser 失败：%s' % e2)
    return 'none'


def parse_args(argv):
    """支持 --port 8080 / --port=8080 两种写法"""
    opts = {'serve_only': False, 'no_browser': False, 'port': 0,
            'app': True, 'tab': False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '--serve-only':
            opts['serve_only'] = True
        elif a == '--no-browser':
            opts['no_browser'] = True
        elif a == '--app':
            opts['app'] = True
        elif a == '--tab':
            opts['tab'] = True
        elif a == '--port':
            if i + 1 < len(argv):
                try:
                    opts['port'] = int(argv[i + 1])
                except ValueError:
                    pass
                i += 1
        elif a.startswith('--port='):
            try:
                opts['port'] = int(a.split('=', 1)[1])
            except ValueError:
                pass
        i += 1
    return opts


def already_running(port):
    """该端口上是不是已经有一个我们的实例在跑"""
    try:
        req = urllib.request.Request('http://127.0.0.1:%d/api/health' % port)
        with urllib.request.urlopen(req, timeout=1.2) as r:
            j = json.loads(r.read().decode('utf-8'))
            return j.get('app') == APP_ID
    except Exception:
        return False


def main():
    opts = parse_args(sys.argv[1:])
    serve_only = opts['serve_only']
    no_browser = opts['no_browser']
    want_app = opts['app'] and not opts['tab']   # 默认：应用窗口
    port = opts['port']

    ensure_dirs()
    log('=' * 50)
    log('启动 · 程序目录=%s' % BASE)
    log('数据目录=%s' % DATA)

    if not port:
        port = PRIMARY_PORT

    # 单实例：如果已经有一个在跑，直接把浏览器指过去，然后退出
    if already_running(port):
        url = 'http://127.0.0.1:%d/' % port
        log('检测到已有实例在运行，直接打开：%s' % url)
        if not no_browser:
            open_browser(url, want_app)
        return 0

    # 绑定端口；被别的程序占用就换随机端口
    httpd = None
    try:
        httpd = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    except OSError as e:
        log('端口 %d 不可用（%s），改用随机端口' % (port, e))
        port = free_port()
        httpd = ThreadingHTTPServer(('127.0.0.1', port), Handler)

    httpd.daemon_threads = True
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    url = 'http://127.0.0.1:%d/' % port
    log('服务地址 %s' % url)

    # 生成一个双击即可打开的快捷方式，作为「自动打开失败」时的保险
    try:
        shortcut = os.path.join(BASE, '打开日记.url')
        with open(shortcut, 'w', encoding='ascii', errors='ignore') as f:
            f.write('[InternetShortcut]\r\nURL=' + url + '\r\n')
        log('快捷方式：%s' % shortcut)
    except Exception as e:
        log('创建快捷方式失败：%s' % e)

    say('=' * 60)
    say(' 日记管理系统 · 桌面版')
    say(' 数据目录：' + DATA)
    say(' 服务地址：' + url)
    say('=' * 60)
    say(' 保持运行中。关闭日记页面后程序会自动退出。')
    say('（若页面没自动打开，请手动访问上面的地址）')
    say('')

    if serve_only:
        try:
            while not SHUTDOWN_FLAG.is_set():
                time.sleep(0.3)
        except KeyboardInterrupt:
            pass
        log('serve-only 结束')
        return 0

    how = 'none'
    if not no_browser:
        how = open_browser(url, want_app) or 'none'
        log('打开方式 = ' + how)

    # 等待：页面心跳停止 或 收到 /api/shutdown
    # 页面每 5 秒 ping 一次；150 秒没动静就认为页面已关闭（容忍后台降频）
    started = time.time()
    fell_back = False
    # 原生窗口初始化 WebView2 需要时间，多给一些；其它方式 8 秒足够
    timeout_s = 20 if how == 'host' else 8
    try:
        while not SHUTDOWN_FLAG.is_set():
            time.sleep(0.5)
            now = time.time()

            # 超时还没加载 → 再用浏览器标签页打开一次，并弹窗告知
            if (not STATE['page_loaded']) and (not fell_back) and (now - started > timeout_s):
                fell_back = True
                log('%d 秒内页面未加载，改用浏览器标签页打开' % timeout_s)
                open_browser(url, False, allow_host=False)
                started = now
                msgbox(
                    '日记窗口没有自动显示出来。\n\n'
                    '已经尝试用浏览器打开；如果仍看不到界面，请：\n\n'
                    '  1) 手动在浏览器地址栏输入：\n     ' + url + '\n\n'
                    '  2) 或双击程序目录下的「打开日记.url」\n\n'
                    '程序会继续在后台运行。数据目录：\n  ' + DATA + '\n\n'
                    '（关闭日记页面后程序会自动退出）',
                    '日记管理系统')

            # 页面曾经加载过，但长时间没有心跳 → 认为页面已关闭
            if STATE['page_loaded']:
                if now - STATE['last_ping'] > 150:
                    log('页面心跳停止，视为已关闭')
                    break
            elif fell_back and (now - started > 120):
                log('仍未连上页面，退出（请看日志中的 HTTP 记录）')
                break
    except KeyboardInterrupt:
        pass

    try:
        httpd.shutdown()
    except Exception:
        pass
    log('退出')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception:
        tb = traceback.format_exc()
        log('未捕获异常：\n' + tb)
        msgbox('程序异常退出：\n\n' + tb[-1200:])
        sys.exit(1)
